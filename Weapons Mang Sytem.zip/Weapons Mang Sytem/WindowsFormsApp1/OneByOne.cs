﻿namespace WindowsFormsApp1
{


    partial class OneByOne
    {
    }
}
