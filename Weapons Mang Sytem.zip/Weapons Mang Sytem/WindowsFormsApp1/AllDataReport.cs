﻿namespace WindowsFormsApp1
{


    partial class AllDataReport
    {

    }
}
