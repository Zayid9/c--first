﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class OwnerInfo : Form
    {
        const string connectionString = "Data Source=OMAR_MOHAMMED\\SQLEXPRESS; Initial Catalog=WEAPONDB;Integrated Security=True;";

        public OwnerInfo()
        {
            InitializeComponent();
        }

        // Function kaan wxuu noosoo aqrinayaa Table ka 
        private void ReadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open Connection
                connection.Open();

                // Query
                string query = "SELECT * FROM Owners";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter sda = new SqlDataAdapter(command);

                    DataTable dt = new DataTable();

                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;

                }

                connection.Close();
            }
        }

        // Functionkana wxuu data noogu shubayaa DataGridViewga
        private void LoadData()
        {
            try
            {
                // Waxaa lagu sameyay Connectionka database marka kowaad
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Queryga oo lagu dooranyo data-da ku jirta table ka Ownerska
                    string query = "SELECT * FROM Owners";

                    // Waxaa halkaan laga sameynyaa SqlCommand si looga shaqeysio query aad soo qortay
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Waxa halkan ka sameysan SqlDataAdapter si loo helo data-da ku jira table-ka ama Dataset-ka
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // DataSet Cusub ayaa ka sameysmay halkaan
                            DataSet dataSet = new DataSet();

                            // waxaa halakan lagu buuxiyay dataSetka table nameka 
                            adapter.Fill(dataSet, "Owners");

                            // Waxaan Ku dhajiyay data-da iney kasoo muuqato dataGridView-ga
                            dataGridView1.DataSource = dataSet.Tables["Owners"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to Log Out of the System?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                MainForm Lform = new MainForm();
                Lform.Show();
                this.Hide();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Waa variable-ka aan u qaatay txtBox yada aan soo sameyy 

            string OwnerID = txtBoxOwnerID.Text;
            string OwnerName = txtBoxOwnerName.Text;
            string Nationality = txtBoxNationality.Text;
            string Sex = comboBoxSex.SelectedItem?.ToString();
            string Tell = txtBoxTell.Text;

            // Xaqiijinta in txtBox-yada maran yihiin iyo inkle
            if (string.IsNullOrWhiteSpace(OwnerName) || string.IsNullOrWhiteSpace(Nationality) || string.IsNullOrWhiteSpace(Sex) || string.IsNullOrWhiteSpace(Tell))
            {
                MessageBox.Show("Please Fill In All The Required Fields", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Connection ka ayaa bilaabanaay
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // query
                string query = "INSERT INTO Owners (OwnerName, Natinality, Sex, Telephone) VALUES ('" + OwnerName + "', '" + Nationality + "', '" + Sex + "' ,'" + Tell + "')";

                // Waxaa halkaan laga sameynyaa SqlCommand si looga shaqeysio query aad soo qortay
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    var result = command.ExecuteNonQuery();

                    if (result != 0)
                    {
                        MessageBox.Show("Owner is Successfully Saved");

                        // Wxey tireysaa data markii successfully saved data eey ku dhhdo text boxes iyo combo box
                        txtBoxOwnerID.Clear();
                        txtBoxOwnerName.Clear();
                        txtBoxNationality.Clear();
                        comboBoxSex.SelectedIndex = -1;
                        txtBoxTell.Clear();

                        // Waa functionka kore
                        ReadData();
                    }
                    else
                    {
                        MessageBox.Show("There was a problem while saving the owner info");
                    }
                }

                connection.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Wxey tireysaa data Ku jirta text boxes iyo combo box

            txtBoxOwnerID.Clear();
            txtBoxOwnerName.Clear();
            txtBoxNationality.Clear();
            comboBoxSex.SelectedIndex = -1;
            txtBoxTell.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Waa variable-ka aan u qaatay txtBox yada aan soo sameyy 
            string OwnerID = txtBoxOwnerID.Text;
            string OwnerName = txtBoxOwnerName.Text;
            string Nationality = txtBoxNationality.Text;
            string Sex = comboBoxSex.SelectedItem?.ToString();
            string Tell = txtBoxTell.Text;

            // Xaqiijinta in txtBox-yada maran yihiin iyo inkle
            if (string.IsNullOrWhiteSpace(OwnerID) || string.IsNullOrWhiteSpace(OwnerName) || string.IsNullOrWhiteSpace(Nationality) || string.IsNullOrWhiteSpace(Sex) || string.IsNullOrWhiteSpace(Tell))
            {
                MessageBox.Show("Please Fill In all The Required Fields", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }

            // Connection ka ayaa bilaabanaya
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // query
                string selectQuery = "SELECT OwnerName, Natinality, Sex, Telephone FROM Owners WHERE OwnerID = @OwnerID";

                // Waxaa halkaan laga sameynyaa SqlCommand si looga shaqeysio query aad soo qortay
                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    // // Dhisida Query SQL si aad u soo ceshato macluumaadka OwnerID
                    selectCommand.Parameters.AddWithValue("@OwnerID", OwnerID);
                    SqlDataReader reader = selectCommand.ExecuteReader();

                    // Waa xaqiijinta Owner Informationka lasoo helay
                    if (reader.Read())
                    {
                        // Soo saarida Xogta Owner ka Databaseka laga soo saarayo
                        string currentOwnerName = reader["OwnerName"].ToString();
                        string currentNationality = reader["Natinality"].ToString();
                        string currentSex = reader["Sex"].ToString();
                        string currentTell = reader["Telephone"].ToString();
                        reader.Close();

                        // In la sameyay iyo inkle Updateka hubi
                        bool dataChanged = currentOwnerName != OwnerName || currentNationality != Nationality || currentSex != Sex || currentTell != Tell;

                        if (dataChanged)
                        {
                            string updateQuery = "UPDATE Owners SET OwnerName = @OwnerName, Natinality = @Natinality, Sex = @Sex, Telephone = @Tell WHERE OwnerID = @OwnerID";
                            using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                            {
                                updateCommand.Parameters.AddWithValue("@OwnerID", OwnerID);
                                updateCommand.Parameters.AddWithValue("@OwnerName", OwnerName);
                                updateCommand.Parameters.AddWithValue("@Natinality", Nationality);
                                updateCommand.Parameters.AddWithValue("@Sex", Sex);
                                updateCommand.Parameters.AddWithValue("@Tell", Tell);

                                // Hadii data wax laga badalo Hawshan ayaa dhaceysa
                                int rowsAffected = updateCommand.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Owner Information Successfully Updated");

                                    // Wxey tireysaa data markii successfully Updated data eey ku dhhdo text boxes iyo combo box
                                    txtBoxOwnerID.Clear();
                                    txtBoxOwnerName.Clear();
                                    txtBoxNationality.Clear();
                                    comboBoxSex.SelectedIndex = -1;
                                    txtBoxTell.Clear();

                                    // Waa functionka kore
                                    ReadData();
                                }
                                else
                                {
                                    MessageBox.Show("Failed to update owner information");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("No Changes Were Made. Please Make Any Update to Save Data.", "No Changes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Owner not found");
                    }
                }
                connection.Close();
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Waa variable-ka aan u qaatay txtBox yada aan soo sameyy 

            string OwnerID = txtBoxOwnerID.Text;

            // Xaqiijinta in txtBox-yada maran yihiin iyo inkle
            if (string.IsNullOrWhiteSpace(OwnerID))
            {
                MessageBox.Show("Please select a row to delete", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // Wxaa lagu tusinayaa Form yar oo lagu leyhy ma hubtaa inaad delete garenyso data-da iyo inkle si loo hubio oo dhaqsaba aan data-da lagaaga delete din
            DialogResult result = MessageBox.Show("Are you sure you want to delete this owner?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // query
                    string query = "DELETE FROM Owners WHERE OwnerID = @OwnerID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@OwnerID", OwnerID);

                        var deleteResult = command.ExecuteNonQuery();

                        if (deleteResult != 0)
                        {
                            MessageBox.Show("Owner Is Successfully Deleted");

                            // Wxey tireysaa data markii successfully Deleted data eey ku dhhdo text boxes iyo combo box
                            txtBoxOwnerID.Clear();
                            txtBoxOwnerName.Clear();
                            txtBoxNationality.Clear();
                            comboBoxSex.SelectedIndex = -1;
                            txtBoxTell.Clear();

                            // Waa functionka kore
                            ReadData();
                        }
                        else
                        {
                            MessageBox.Show("There was a problem while deleting the owner info");
                        }
                    }

                    connection.Close();
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Waxaa lagu shubyaa txtBox leh xogta safka la doortay

                txtBoxOwnerID.Text = selectedRow.Cells["OwnerID"].Value.ToString();
                txtBoxOwnerName.Text = selectedRow.Cells["OwnerName"].Value.ToString();
                txtBoxNationality.Text = selectedRow.Cells["Natinality"].Value.ToString();
                comboBoxSex.SelectedItem = selectedRow.Cells["Sex"].Value.ToString();
                txtBoxTell.Text = selectedRow.Cells["Telephone"].Value.ToString();
            }
        }

        private void OwnerInfo_Load(object sender, EventArgs e)
        {
            // Waa U dejinta qaabka xulashada DataGridviewga la doortay Row giisa ama Column kiisa

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Ku shubista xogta DataGridView marka foomku soo baxo
            LoadData();
        }
    }
}
